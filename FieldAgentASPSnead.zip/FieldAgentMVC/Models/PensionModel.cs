﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FieldAgentMVC.Models
{
    public class PensionModel
    {
        [Required(ErrorMessage = "AgencyId is required")]   
        public int AgencyId { get; set; }
    }
}
