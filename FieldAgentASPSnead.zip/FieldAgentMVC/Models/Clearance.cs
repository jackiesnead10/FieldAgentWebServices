﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FieldAgentMVC.Models
{
    public class Clearance
    {
        [Required(ErrorMessage = "agencyId is Required.")]
        public int agencyId { get; set; }

        [Required(ErrorMessage = "securityId is Required.")]
        public int securityId { get; set; }
    }
}
