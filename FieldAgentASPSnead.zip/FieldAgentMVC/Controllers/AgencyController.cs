﻿using FieldAgent.Core.Entities;
using FieldAgent.Core.Interfaces.DAL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FieldAgentMVC.Controllers
{
    public class AgencyController : Controller
    {
        private IAgencyRepository _agencyRepository;

        public AgencyController(IAgencyRepository agencyRepository)
        {
            _agencyRepository = agencyRepository;
        }
        [Route("/agencies")]
       [HttpGet]
       public IActionResult Index()
       {
           var result = _agencyRepository.GetAll();

           if (result.Success)
           {
               return View(result.Data);
           }
           else
           {
               throw new Exception(result.Message);
           }

       }

       /*[Route("/agencies")]
       [HttpGet]
       public IActionResult GetAll()
       {
           var result = _agencyRepository.GetAll();

           if (result.Success)
           {
               return View(result.Data);
           }
           else
           {
               throw new Exception(result.Message);
           }
       }*/
        [Route("/agencies/add")]
        [HttpGet]
        public IActionResult Add()
        {
            var model = new Agency();
            return View(model);
        }
        [Route("/agencies/add")]
        [HttpPost]
        public IActionResult Add(Agency model)
        {
            if (ModelState.IsValid)
            {
                var result = _agencyRepository.Insert(model);

                if (result.Success)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    // todo: add validation messages to form later
                    throw new Exception(result.Message);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
            
        }
        [Route("agencies/edit/{id}")]
        [HttpGet]
        public IActionResult Edit(int id)
        {

            var result = _agencyRepository.Get(id);

            if (result.Success)
            {
                return View(result.Data);
            }
            else
            {
                throw new Exception("Unable to find Agency based on ID provided.");
            }
           
       
        }
        [Route("agencies/edit/{id}")]
        [HttpPost]
        public IActionResult Edit(Agency model)
        {
            if (ModelState.IsValid)
            {
                var result = _agencyRepository.Update(model);

                if (result.Success)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    // todo: add validation messages to form later
                    throw new Exception("Unable to Update Agency.");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
        [Route("/agencies/delete/{id}")]
        [HttpGet]
        public IActionResult Remove(int id)
        {
            var result = _agencyRepository.Get(id);

            if (result.Success)
            {
                return View(result.Data);
            }
            else
            {
                throw new Exception("Unable to delete agency");
            }
        }

        [Route("/agencies/delete/{id}")]
        [HttpPost]
        public IActionResult Remove(Agency model)
        {
            var result = _agencyRepository.Delete(model.AgencyId);

            if (result.Success)
            {
                return RedirectToAction("Index");
            }
            else
            {
                throw new Exception("Unable to delete agency");
            }
        }

    }
}
