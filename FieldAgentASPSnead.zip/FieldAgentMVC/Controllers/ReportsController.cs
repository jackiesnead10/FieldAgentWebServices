﻿using FieldAgent;
using FieldAgent.Core.DTOs;
using FieldAgent.Core.Entities;
using FieldAgent.Core.Interfaces.DAL;
using FieldAgentMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FieldAgentMVC.Controllers
{
    public class ReportsController : Controller
    {
        private FieldAgentContext _context;
        private IReportsRepository _reportsRepository;
        public ReportsController(IReportsRepository reportsRepository, FieldAgentContext context)
        {
            _reportsRepository = reportsRepository;
            _context = context;
        }

        [Route("/reports")]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        
      
        [Route("/reports/topagents")]
        [HttpGet]
        public IActionResult GetTopAgents()
        {
            var result = _reportsRepository.GetTopAgents();
            if (result.Success)
            {
                return View(result.Data);
            }
            else
            {
                throw new Exception("Error: Can't locate top agents");
            }
        }
        [Route("/reports/pensionlist")]
        [HttpPost]
        public IActionResult GetPensionList(PensionModel pensionModel)
        {
           
            Response<List<PensionListItem>> result;
        
           
           result = _reportsRepository.GetPensionList(pensionModel.AgencyId);
            
            
            if(result.Success)
            {
                return View(result.Data);
            }
            else
            {
                throw new Exception("Error: Can't locate pension list");
            }
        }
        [Route("/reports/getpensionlistparameters")]
        [HttpGet]
        public IActionResult GetPensionReportParameters()
        {
            PensionModel pensionModel = new PensionModel();
            return View(pensionModel);
        }
        [Route("/reports/getsecurityauditparameters")]
        [HttpGet]
        public IActionResult GetSecurityClearanceParameters()
        {
            Clearance clearance = new Clearance();
             return View(clearance);
        }



        [Route("/reports/securityaudit")]
        [HttpPost]
        public IActionResult GetSecurityAudit(Clearance clearance)
        {
            var result = _reportsRepository.AuditClearance(clearance.securityId, clearance.agencyId);
            if (result.Success)
            {
                return View(result.Data);
            }
            else
            {
                throw new Exception("Error: Can't locate audit clearance");
            }
        }
    }
}
