﻿using FieldAgent.Core.Entities;
using FieldAgent.Core.Interfaces.DAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FieldAgentMVC.ApiController
{
    [Route("api/[controller]")]
    [ApiController]
    public class AgentController : ControllerBase
    {
         private readonly IMissionRepository _missionRepository;
        private readonly IAgentRepository _agentRepository;

        public AgentController(IMissionRepository missionRepository, IAgentRepository agentRepository)
        {
            _missionRepository = missionRepository;
            _agentRepository = agentRepository;
        }
        [HttpGet, Authorize]
        [Route("/api/[controller]/{id}/missions", Name = "GetMissions")]
        public IActionResult GetMissions(int id)
        {
                var result = _agentRepository.GetMissions(id);
                if (result.Success)
                {
                    return Ok(result.Data);
                }
                else
                {
                    return BadRequest(result.Message);
                }
            
        }

        [HttpGet, Authorize]
        [Route("/api/[controller]/{id}", Name = "GetAgent")]
        public IActionResult GetAgent(int id)
        {
            var result = _agentRepository.Get(id);

            if (result.Success)
            {
                return Ok(result.Data);
            }
            else
            {
                return BadRequest(result.Message);
            }

        }
        [HttpPost, Authorize]
        [Route("/api/[controller]/add", Name = "AddAgent")]
        //public IActionResult AddAgent([FromBody] string FirstName, [FromBody] string LastName, [FromBody] string DateOfBirth, [FromBody] decimal Height)
        public IActionResult AddAgent([FromBody] Agent agent)
        {
            /*
            Agent a = new Agent();
            a.FirstName = FirstName;
            a.LastName = LastName;
            a.DateOfBirth = DateTime.Parse(DateOfBirth);
            a.Height = Height;
            
            */
            if (ModelState.IsValid)
            {
                var result = _agentRepository.Insert(agent);

                if (result.Success)
                {
                    return CreatedAtRoute(nameof(GetAgent), new { id = agent.AgentId }, agent);
                }
                else
                {
                    return BadRequest(result.Message);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
        [HttpPut, Authorize]
        [Route("/api/[controller]/{id}/edit", Name = "EditAgent")]
        public IActionResult EditAgent([FromBody] Agent agent, int id)
        {
            agent.AgentId = id;
            if (!_agentRepository.Get(agent.AgentId).Success)
            {
                return NotFound($"Agent {agent.AgentId} not found");
            }

            if (ModelState.IsValid)
            {
                var result = _agentRepository.Update(agent);

                if (result.Success)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest(result.Message);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }

        }
        [HttpDelete, Authorize]
        [Route("/api/[controller]/{id}/delete", Name = "DeleteAgent")]
        public IActionResult DeleteAgent(int id)
        {
            if (!_agentRepository.Get(id).Success)
            {
                return NotFound($"Agent {id} not found");
            }

            var result = _agentRepository.Delete(id);

            if (result.Success)
            {
                return Ok();
            }
            else
            {
                return BadRequest(result.Message);
            }
        }


       
        
    }
}
