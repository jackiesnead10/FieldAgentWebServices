﻿using FieldAgent;
using FieldAgent.Core.Entities;
using FieldAgent.Core.Interfaces.DAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FieldAgentMVC.ApiController
{
    [Route("api/[controller]")]
    [ApiController]
    public class AliasController : ControllerBase
    {
        private readonly IAgentRepository _agentRepository;
        private readonly IAliasRepository _aliasRepository;

        public AliasController(IAgentRepository agentRepository, IAliasRepository aliasRepository)
        {
            _aliasRepository = aliasRepository;
            _agentRepository = agentRepository;
        }
        [HttpGet, Authorize]
        [Route("/api/[controller]/{id}", Name = "GetAlias")]

        public IActionResult GetAlias(int id)
        {
            var result = _aliasRepository.Get(id);

            if (result.Success)
            {
                return Ok(result.Data);

            }
            else
            {
                return BadRequest(result.Message);
                
            }

        }
        [HttpGet, Authorize]
        [Route("/api/[controller]/{id}/agent", Name = "GetAliasAgent")]
        public IActionResult GetAliasAgent(int id)
        {
            var result = _aliasRepository.GetByAgent(id);

            if (result.Success)
            {
                return Ok(result.Data);
            }
            else
            {
                return BadRequest(result.Message);
            }

        }
        [HttpPost, Authorize]
        [Route("/api/[controller]/add", Name = "AddAlias")]

       // public IActionResult AddAlias(string AliasName, Guid InterpollId, string Persona)
       public IActionResult AddAlias([FromBody] Alias a)
        {
            a.InterpolId = Guid.NewGuid();
            Response<Agent> response  = _agentRepository.Get(a.AgentId);
            if (!response.Success)
            {
                return NotFound($"Agent {a.AgentId} not found");
            }
            a.Agent = response.Data;
            /*
            Alias a = new Alias();
            a.AliasName = AliasName;
            a.InterpolId = InterpollId;
            a.Persona = Persona;
            */
            if (ModelState.IsValid)
            {
                var result = _aliasRepository.Insert(a);

                if (result.Success)
                {
                    return CreatedAtRoute(nameof(GetAlias), new { id = a.AliasId }, a);
                }
                else
                {
                    return BadRequest(result.Message);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
        [HttpPut, Authorize]
        [Route("/api/[controller]/{id}/edit", Name = "EditAlias")]

        public IActionResult EditAlias([FromBody] Alias alias, int id)
        {
            alias.AliasId = id;
            
            var response = _aliasRepository.Get(alias.AliasId);
            if (!response.Success)
            {
                return NotFound($"Building {alias.AliasId} not found");
            }
            if(alias.AliasName == null)
            {
                alias.AliasName = response.Data.AliasName;
            }
            if(alias.InterpolId == Guid.Parse("00000000-0000-0000-0000-000000000000"))
            {
                alias.InterpolId = response.Data.InterpolId;
            }
            if(alias.Agent == null)
            {
                alias.Agent = response.Data.Agent;
            }
            if(alias.Persona == null)
            {
                alias.Persona = response.Data.Persona;
            }

            if (ModelState.IsValid)
            {
                var result = _aliasRepository.Update(alias);

                if (result.Success)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest(result.Message);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
        [HttpDelete("{id}"), Authorize]
        [Route("/api/[controller]/{id}/delete", Name = "DeleteAlias")]

        public IActionResult DeleteAlias(int id)
        {
            if (!_aliasRepository.Delete(id).Success)
            {
                return NotFound($"Alias {id} not found");
            }

            var result = _aliasRepository.Delete(id);

            if (result.Success)
            {
                return Ok();
            }
            else
            {
                return BadRequest(result.Message);
            }
        }


       

    }
}

