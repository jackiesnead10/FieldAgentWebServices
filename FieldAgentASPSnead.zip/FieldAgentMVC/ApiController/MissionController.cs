﻿using FieldAgent.Core.Entities;
using FieldAgent.Core.Interfaces.DAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FieldAgentMVC.ApiController
{
    [Route("api/[controller]")]
    [ApiController]
    public class MissionController : ControllerBase
    {

        private readonly IMissionRepository _missionRepository;
        private readonly IAgentRepository _agentRepository;

        public MissionController(IMissionRepository missionRepository, IAgentRepository agentRepository)
        {
            _missionRepository = missionRepository;
            _agentRepository = agentRepository;
        }
        [HttpGet, Authorize]
        [Route("/api/[controller]/{id}", Name = "GetMission")]
        public IActionResult GetMission(int id)
        {
            var result = _missionRepository.Get(id);

            if (result.Success)
            {
                return Ok(result.Data);

            }
            else
            {
                return BadRequest(result.Message);
            }

        }
        [HttpGet, Authorize]
        [Route("/api/[controller]/Agency/{id}", Name = "GetByAgency")]
        public IActionResult GetMissionByAgency(int id)
        {
            var result = _missionRepository.GetByAgency(id);

            if (result.Success)
            {
                return Ok(result.Data);
            }
            else
            {
                return BadRequest(result.Message);
            }

        }
        [HttpGet, Authorize]
        [Route("/api/[controller]/Agents/{id}", Name = "GetMissionByAgent")]
        public IActionResult GetMissionByAgent(int id)
        {
            var result = _missionRepository.GetByAgent(id);

            if (result.Success)
            {
                return Ok(result.Data);
            }
            else
            {
                return BadRequest(result.Message);
            }

        }
        [HttpPost, Authorize]
        [Route("/api/[controller]/Add", Name = "AddMission")]
        public IActionResult AddMission([FromBody] Mission m)
       // public IActionResult AddMission(string CodeName, string Notes, DateTime StartDate, DateTime ProjectedEndDate, DateTime ActualEndDate, Decimal OperationalCost)
        {
            /*
            Mission m = new Mission();
            m.CodeName = CodeName;
            m.Notes = Notes;
            m.StartDate = StartDate;
            m.ProjectedEndDate = ProjectedEndDate;
            m.ActualEndDate = ActualEndDate;
            m.OperationalCost = OperationalCost;
            */

            if(m.StartDate > m.ProjectedEndDate)
            {
                return BadRequest("ProjectedEndDate cannot be before StartDate.");
            }

            if(m.StartDate > m.ActualEndDate)
            {
                return BadRequest("ActualEndDate cannot be before StartDate.");
            }
            if(ModelState.IsValid)
            {
                var result = _missionRepository.Insert(m);

                if (result.Success)
                {
                    return CreatedAtRoute(nameof(GetMission), new { id = m.MissionId }, m);
                }
                else
                {
                    return BadRequest(result.Message);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
        [HttpPut, Authorize]
        [Route("/api/[controller]/{id}/edit", Name = "EditMission")]
        public IActionResult EditMission([FromBody] Mission mission, int id)
        {
            mission.MissionId = id;
            if (!_missionRepository.Get(mission.MissionId).Success)
            {
                return NotFound($"Mission {mission.MissionId} not found");
            }


            if (ModelState.IsValid)
            {


                var result = _missionRepository.Update(mission);

                if (result.Success)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest(result.Message);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
        [HttpDelete("{id}"), Authorize]
        [Route("/api/[controller]/{id}/delete", Name = "DeleteMission")]
        public IActionResult DeleteMission(int id)
        {
            if (!_missionRepository.Get(id).Success)
            {
                return NotFound($"Building {id} not found");
            }

            var result = _missionRepository.Delete(id);

            if (result.Success)
            {
                return Ok();
            }
            else
            {
                return BadRequest(result.Message);
            }
        }


       
    }
}

