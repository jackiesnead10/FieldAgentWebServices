﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FieldAgent.Core.Entities
{
    public class Alias
    {
        public int AliasId { get; set; }

        [Required(ErrorMessage = "AgentId is required.")]
        public int AgentId { get; set; }

        [Required(ErrorMessage = "AliasName is required.")]
        [StringLength(50, ErrorMessage = "AliasName cannot be more than 50 characters.")]
        public string AliasName { get; set; }

        public Guid InterpolId { get; set; }

        [Required(ErrorMessage = "Persona is required.")]
        [StringLength(50, ErrorMessage = "Persona cannot be more than 50 characters.")]
        public string Persona { get; set; }

        public Agent Agent { get; set; }


    }
}
