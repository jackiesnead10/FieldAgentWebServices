﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FieldAgent.Core.Entities
{
    public class SecurityClearance
    {
        public int SecurityClearanceId { get; set; }

        [Required(ErrorMessage = "SecurityClearanceName is Required.")]
        [StringLength(50, ErrorMessage = "SecurityClearanceName cannot be more than 50 characters.")]
        public string SecurityClearanceName { get; set; }
        public List<AgencyAgent> agencyAgents{ get; set; }

      //  SecurityClearance secClear = new SecurityClearance() { SecurityClearanceId = 1, SecurityClearanceName = "Eagle" };
    }
}
