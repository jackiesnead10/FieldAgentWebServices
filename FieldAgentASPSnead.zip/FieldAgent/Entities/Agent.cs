﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FieldAgent.Core.Entities
{
    public class Agent
    {
        public int AgentId { get; set; }

        [Required(ErrorMessage = "FirstName is required.")]
        [StringLength(50, ErrorMessage = "FirstName cannot be more than 50 characters.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "LastName is required.")]
        [StringLength(50, ErrorMessage = "LastName cannot be more than 50 characters.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "DateOfBirth is required.")]
        [DataType(DataType.DateTime)]
        public DateTime DateOfBirth { get; set; }
        
        [Required(ErrorMessage = "Height is required.")]
        public decimal Height { get; set; }
      
        public List<Alias> Alias { get; set; }


    }
}
