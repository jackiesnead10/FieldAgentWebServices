﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FieldAgent.Core.Entities
{
    public class Agency 
    {
        public int AgencyId { get; set; }

        [Required(ErrorMessage = "ShortName is required")]
        [StringLength(25, ErrorMessage = "ShortName cannot exceed 25 characters.")]
        public string ShortName { get; set; }


        [Required(ErrorMessage = "LongName is required")]
        [StringLength(255, ErrorMessage = "LongName cannot exceed 255 characters.")]
        public string LongName { get; set; }

        public List<Location> Locations { get; set; }
        public List<Mission> Missions { get; set; }
        public List<AgencyAgent> Agent { get; set; }

       

    }
}
