﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FieldAgent.Core.Entities
{
    public class Mission
    {
        public int MissionId { get; set; }

        [Required(ErrorMessage = "AgencyId is required")]
        public int AgencyId { get; set; }

        [Required(ErrorMessage = "CodeName is Required.")]
        [StringLength(50, ErrorMessage = "Code Name cannot be more than 50 characters.")]
        public string CodeName { get; set; }


        public string Notes { get; set; }

        [Required(ErrorMessage = "StartDate is Required.")]
        [DataType(DataType.DateTime)]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "ProjectedEndDate is Required.")]
        [DataType(DataType.DateTime)]
        public DateTime ProjectedEndDate { get; set; }
        public DateTime ActualEndDate { get; set; }

        [Required(ErrorMessage = "OperationalCost is required.")]
        public Decimal OperationalCost { get; set; }

        public Agency Agency { get; set; }

        public List<MissionAgent> MissionAgents { get; set; }


    }
}
